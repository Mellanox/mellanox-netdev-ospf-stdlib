# CHANGELOG
v1.0.0 (1.1.2014) - Added module types
